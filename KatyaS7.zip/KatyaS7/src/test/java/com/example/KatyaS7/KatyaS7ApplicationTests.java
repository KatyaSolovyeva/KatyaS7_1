package com.example.KatyaS7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KatyaS7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
